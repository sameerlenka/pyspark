run docker build command

docker build -t airflow-workspace:latest .
