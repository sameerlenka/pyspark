# Update the scheduling arguments as defined
default_args = {
  'owner': 'Engineering',
  'start_date': datetime(____, ____, ____),
  'email': ['airflowresults@datacamp.com'],
  'email_on_failure': False,
  'email_on_retry': False,
  'retries': 3,
  'retry_delay': timedelta(minutes=____)
}

dag = DAG('update_dataflows', default_args=default_args, schedule_interval='____')
