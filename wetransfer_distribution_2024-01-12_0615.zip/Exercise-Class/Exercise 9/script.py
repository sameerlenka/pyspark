# Import the Operator
from ____ import ____

# Define the task
email_manager_task = ____(
    task_id='email_manager',
    ____='manager@datacamp.com',
    ____='Latest sales JSON',
    html_content='Attached is the latest sales JSON file as requested.',
    ____='parsedfile.json',
    dag=process_sales_dag
)

# Set the order of tasks
pull_file_task ____ parse_file_task ____ email_manager_task