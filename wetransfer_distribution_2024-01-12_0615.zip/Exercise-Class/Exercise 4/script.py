# Define a new pull_sales task
pull_sales = ____(
    task_id='pullsales_task',
    ____,
    dag=analytics_dag
)

# Set pull_sales to run prior to cleanup
pull_sales ____ cleanup

# Configure consolidate to run after cleanup
____

# Set push_data to run last
consolidate ____