# Create the task
pull_file_task = ____(
    ____='pull_file',
    # Add the callable
    python_callable=____,
    # Define the arguments
    ____={'URL':'http://dataserver/sales.json', '____':'latestsales.json'},
    dag=process_sales_dag
)
