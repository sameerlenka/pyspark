# Add another Python task
____ = ____(
    task_id=____,
    # Set the function to call
    ____
    # Add the arguments
    ____={'inputfile':'latestsales.json', 'outputfile':'parsedfile.json'},
    # Add the DAG
    dag=____
)