# Define a second operator to run the `consolidate_data.sh` script
consolidate = ____(
    task_id='consolidate_task',
    bash_command=____,
    dag=____)

# Define a final operator to execute the `push_data.sh` script
push_data = ____(
    ____=____,
    ____=____,
    ____)