# Import the DAG object
from ____ import ____


# Define the default_args dictionary
  ____ = {
  'owner': '____',
  'start_date': datetime(____,____,____),
  'retries': 
}


# Instantiate the DAG object
____ = ____(____, default_args=____)
