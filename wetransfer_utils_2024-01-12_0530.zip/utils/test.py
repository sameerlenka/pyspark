from kafka import KafkaProducer
import time
import six
import sys
import random
from device_events import generate_events

if sys.version_info >= (3, 12, 0): 
    print("It is trrue")
    # sys.modules['kafka.vendor.six.moves'] = six.moves