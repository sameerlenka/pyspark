Copy yml file in some folder

Go to the folder and run the following command 

docker compose up

In other terminal do the following steps 


docker ps 

Copy the container id 

docker exec -it <container_id> /bin/bash 

# Setup test environment
# Inside the kafka container:
kafka-topics.sh --create --replication-factor 1 --bootstrap-server localhost:9092 --topic test_topic

kafka-topics.sh --list --bootstrap-server localhost:9092

kafka-console-producer.sh --bootstrap-server localhost:9092 --topic test_topic --property "parse.key=true" --property "key.separator=:"


------------------------Not ot be done inside kafka cluster------------
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0 /src/read_test_stream.py